from . import brute_force

children = [('brute_force', 'Brute_force', 'Forca\nBruta')]

__all__ = [a[0] for a in children]
