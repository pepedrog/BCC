
def Bentley_Ottmann (segs):
    return
    