#!/usr/bin/env python
"""Implementacoes das operacoes graficas usadas nos algoritmos

Sub-modulos:
tk:    implementacao usando Tk
gnome: implementacao usando GNOME
"""
