#!/usr/bin/env python
"""Implementacao "dummy" das operacoes graficas"""

def init_display (app):
	pass

def get_canvas ():
	pass

def update ():
	pass

def sleep ():
	pass

def plot_disc (x, y, color, r):
	pass

def plot_segment (x0, y0, x1, y1, color, linewidth):
	pass

def plot_vert_line (x, color, linewidth):
	pass

def plot_horiz_line (y, color, linewidth):
	pass

def plot_delete (widget):
	pass

def config_canvas (minx, maxx, miny, maxy):
	pass

def hide_algorithm ():
	return 1
