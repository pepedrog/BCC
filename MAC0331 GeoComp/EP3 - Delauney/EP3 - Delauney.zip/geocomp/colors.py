#!/usr/bin/env python

colors = (
"red",
"yellow",
"green",
"cyan",
"blue"
)

