# Geometria
Plataforma feita em python para implementação de algoritmos geométricos

Baseado na matéria MAC0331 - Geometria Computacional. Os algoritmos em */geocomp* foram feitos por mim, a interface e o front-end gráfico foram feitos pelos colaboradores da matéria.

Para rodar, baixe todo o repositório e rode o tkgeocomp.py
