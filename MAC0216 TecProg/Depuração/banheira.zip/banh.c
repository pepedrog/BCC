#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "xwc.h"
#include <X11/keysymdef.h>

/* Tela para a saida */
#define TAM_H 700
#define TAM_V 700
int Tx = TAM_H;							/* Tamanho horizontal da tela */
int Ty = TAM_V;							/* Tamanho vertical da tela */
char **tela;							/* A propria */

/* Dominio da funcao (retangulo) */
double xi = -5.0, xf = 5.0;				/* intervalo horizontal */
double yi = -5.0, yf = 5.0;				/* intervalo vertical */

/* Funcao desejada */
double f(double x, double y)
{
  return x*x + y*y;
}

/* Parametros de calculo */
double h=.3, eps = .15;				/* Altura das curvas e o erro */

/* Verifica se `z' e' um multiplo de h a menos de eps */
int modulo(double z)
{
	double m;
	long int k;
	m = fabs(z) + eps;
	k = (int) (m/h);
	return (m-k*h) < eps/2.0 ? 1 : 0;
}

/* Para imprimir mensagens de erro */
#define puterr(x) fputs(x, stderr)

/* Descricao do uso do programa */
void uso(char *nome)
{
	printf("\nUso:\n\t%s [-[ehXY]<num>] [-[if](<num>,<num>)\n", nome);
	puts("\tOnde:\n");
	puts("\t\t-e : redefine o erro na altura.");
	puts("\t\t-h : redefine a altura entre as  curvas de nivel.");
	puts("\t\t-X : redefine a altura da tela de saida.");
	puts("\t\t-Y : redefine a largura da tela de saida.");
	puts("\t\t-i : redefine o canto inferior esquerdo do dominio.");
	puts("\t\t-f : redefine o canto superior direito do dominio.");
	puts("\tExemplo:\n\t\tbanh -e.01 -h2.912 -X200 -Y120 -i(-2.1,9.0)");
	exit(1);
}

int main(int ac, char **av)
{
  int ai, aj;					/* Variaveis de laco auxiliares */
  double dx, dy;			   /* Incremento em x e y, para o desenho */
  WINDOW *w;					/* Janela */
  int cor, branco;
  
  /* Interpreta a linha de comando */
  for (ai = 1; ai < ac; ai++)  {
	if (av[ai][0] != '-') {			/* As opcoes devem comecar com '-' */
	  puterr("Opcao ignorada!");
	  continue;
	}
	switch (av[ai][1]) {
	case 'e':						/* Redefine epsilon */
	  eps = atof(&av[ai][2]);
	  printf("eps = %f\n", eps);
	  break;
	  
	case 'h':						/* Nova distancia entre as curvas */
	  h = atof(&av[ai][2]);
	  printf("h = %f\n", h);
	  break;
	  
	case 'X':						/* Largura  da tela */
	  Tx = atoi(&av[ai][2]);
	  printf("Largura da tela = %d\n", Tx);
	  break;
	  
	case 'Y':						/* Altura da tela */
	  Ty = atoi(&av[ai][2]);
	  printf("Altura da tela = %d\n", Ty);
	  break;
	  
	case 'i':
	  if (sscanf(&av[ai][2], "(%lf,%lf)", &xi, &yi) != 2) {
		puterr("Formato errado");
		uso(av[0]);
	  }
	  printf("Canto inferior esquerdo : (%f,%f)\n", xi,yi);
	  break;
	  
	case 'f':
	  if (sscanf(&av[ai][2], "(%lf,%lf)", &xf, &yf) != 2) {
		puterr("Formato errado");
		uso(av[0]);
	  }
	  printf("Canto inferior  direito : (%f,%f)\n", xf, yf);
	  break;
	  
	default:						/* Erro */
	  puterr("Opcao indefinida");
	  uso(av[0]);
	  break;
	}
  }
  
  /* Abertura da janela */
  w = InitGraph(Tx,Ty, "Banheira");
  /* Leitura do teclado */
  InitKBD(w);  

  /* incremento em x e y */
  dx = (xf - xi)/Tx;					/* delta x */
  dy = (yf - yi)/Ty;					/* delta y */
  
  cor = WNamedColor("black");
  branco = WNamedColor("white");
  /* calculo principal */
  for (aj = 0; aj < Ty; aj++) {
	for (ai = 0; ai < Tx; ai++) {
	  if (modulo(f(xi + dx*ai, yi + dy*aj))) 
		WPlot(w,ai,aj, cor);
	  else 
		WPlot(w,ai,aj, branco);
	}
  }
  
  puts("Pressione <enter> para sair\n");

  do {
	WGetKey(w);
  } while(WLastKeySym() != XK_Return);

  exit(0);
}
