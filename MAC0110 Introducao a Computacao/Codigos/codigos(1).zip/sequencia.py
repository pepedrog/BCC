# gera sequência 2**0 até 2**10
contador=0
print(2**contador)
while contador<10:
    contador = contador+1
    print(2**contador)
