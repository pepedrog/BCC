# contador regressivo de 10 a 0
contador=10
while contador>0:
    print(contador)
    contador = contador-1
print(contador)
