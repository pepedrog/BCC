# contador progressivo de 0 a 10
contador=0
print(contador)
while contador<10:
    contador = contador+1
    print(contador)
